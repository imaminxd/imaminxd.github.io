#!/bin/bash
git pull
git add .
git commit -a -m "commit" 
git push
