---
layout: page
title: Personal Web Page
description: Link to the Personal Web Page Source Code on GitHub
img: assets/img/jpg/prof_pic.jpg
redirect: https://github.com/amindarijani/amindarijani.github.io
importance: 1
category: finished
---

### ONLY A REDIRECTION
