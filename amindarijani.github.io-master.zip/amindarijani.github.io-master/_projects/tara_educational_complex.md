---
layout: page
title: Tara Educational Complex
description: Tara Educational Complex
img: assets/img/jpg/tara_school.jpg
redirect: https://adarijani.github.io/tara-educational-complex/
importance: 1
category: Personal Experiences
---

### construction
