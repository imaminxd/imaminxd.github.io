---
layout: page
title: pandoc book template
description: pandoc book template
img: assets/img/svg/book.svg
redirect: https://github.com/adarijani/book_pandoc_template
importance: 2
category: finished
---

### ONLY A REDIRECTION
