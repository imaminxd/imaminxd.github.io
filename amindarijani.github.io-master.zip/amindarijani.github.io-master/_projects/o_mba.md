---
layout: page
title: MBA; Self Taught
description:  MBA; Self Taught
img: assets/img/svg/mba.svg
importance: 1
category: ongoing
---

#### Plan

So my plan is to self-taugth myself an MSc in Finance and an MBA. I am gonna use the [Stanford Business School Course List](https://bulletin.stanford.edu/departments/GSB/courses) and get on them.

##### Accounting

- Accounting Principles by WEYGANDT, KIMMEL, and MITCHELL [Link](https://www.wiley.com/en-us/Accounting+Principles%2C+14th+Edition-p-9781119707080)
- GnuCash [Link](https://www.gnucash.org/)

###### I Have NO Idea of What Comes Next :-)
