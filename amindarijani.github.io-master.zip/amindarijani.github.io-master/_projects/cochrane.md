---
layout: page
title: Cochrane
description: Assistant at Cochrane Iran Associate Center
img: assets/img/jpg/asiakadeh.jpg
redirect: https://adarijani.github.io/asiakadeh-ecotourism-resort/
importance: 1
category: Professional Experiences
---

### construction
