---
layout: page
title: Data Science; Self Taught
description:  Data Science; Self Taught
img: assets/img/png/data_science.png
importance: 2
category: ongoing
---



#### Plan

I've set out to self-educate in Data Science. My approach involves leveraging various resources available online to develop a comprehensive understanding and skill set in this field.

##### Foundations

- Intro to Data Science by Kaggle Platform Team [Link](https://www.kaggle.com/learn)
- Introduction to Data Science by Jeffrey Stanton [Link](https://www.amazon.com/Introduction-Data-Science-Jeffrey-Stanton/dp/0615983147)
- Python for Data Analysis by Wes McKinney [Link](https://www.oreilly.com/library/view/python-for-data/9781491957653/)

##### Machine Learning

- Machine Learning by Andrew Ng on Coursera [Link](https://www.coursera.org/learn/machine-learning)
- Hands-On Machine Learning with Scikit-Learn, Keras, and TensorFlow by Aurélien Géron [Link](https://www.oreilly.com/library/view/hands-on-machine-learning/9781492032632/)

##### Data Visualization

- Storytelling with Data by Cole Nussbaumer Knaflic [Link](http://www.storytellingwithdata.com/)
- Data Visualisation: A Handbook for Data Driven Design by Andy Kirk [Link](https://www.amazon.com/Data-Visualisation-Handbook-Driven-Design/dp/1473912148)

###### To Be Continued...

