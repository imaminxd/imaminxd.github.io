---
layout: page
title: www
description: www
img: assets/img/svg/www.svg
importance: 1
category: teaching
---

#### Search Engines

- [Google](https://www.google.com/)
  * Advanced Google Search [pdf](https://kak.kornev-online.net/FILES/KAK%20-%2026%20Top%20Advanced%20Google%20Search%20Tips%20n%20Tricks%20and%20Techniques.pdf)
- [bing](https://www.bing.com/)
- [DuckDuckGo](https://duckduckgo.com/)

#### Email Services

- [Gmail](https://www.google.com/gmail/about/)

#### Email Clients

- [Thunderbird](https://www.thunderbird.net)
- [Outlook](https://outlook.live.com/owa/)

#### Cloud Services

- [pCloud](https://www.pcloud.com/)
- [iCloud](https://www.icloud.com/)
- [Dropbox](https://www.dropbox.com/)
- [Google Drive](https://www.google.com/drive/)
- [sync](https://www.sync.com/)


continued:-)
