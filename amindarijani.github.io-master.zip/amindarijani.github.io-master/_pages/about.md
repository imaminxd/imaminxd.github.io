---
layout: about
title: About
permalink: /
subtitle: Studying M.Sc. in Medical Biotechnology at <a href='https://www.uniupo.it/en'> University of Eastern Piedmont </a>, <a href='https://www.google.com/maps/place/28100+Novara,+Province+of+Novara/@45.4538818,8.5745814,13z/data=!3m1!4b1!4m6!3m5!1s0x47865a204242336d:0x4d210e35fa2980f0!8m2!3d45.44693!4d8.6221612!16zL20vMGQ0cHpu?entry=ttu'> NOVARA, ITALY </a>

profile:
  align: right
  image: prof_pic.jpg
  image_circular: false # crops the image to make it circular
  address: >
    <p> <a href='mailto:mamindarijani@gmail.com'> mamindarijani@gmail.com </a> </p>
    <p> <a href='mailto:20058571@studenti.uniupo.it'> 20058571@studenti.uniupo.it </a> </p>
    <p> <a href='mailto:ma.darijani@kmu.ac.ir'> ma.darijani@kmu.ac.ir </a> </p>
    <p> <a href='tel:+393513301266'> +393513301266 </a> </p>
    <p> <a href='https://www.google.com/maps/place/28100+Novara,+Province+of+Novara/@45.4538818,8.5745814,13z/data=!3m1!4b1!4m6!3m5!1s0x47865a204242336d:0x4d210e35fa2980f0!8m2!3d45.44693!4d8.6221612!16zL20vMGQ0cHpu?entry=ttu'> NOVARA, ITALY </a> </p>

news: true # includes a list of news items
selected_papers: false # includes a list of papers marked as "selected={true}"
social: true # includes social icons at the bottom of the page
---
Holding a Professional Doctorate Degree from the <a href='https://www.kmu.ac.ir/en'> Kerman University of Medical Sciences </a>, <a
href='https://www.google.com/maps/place/Kerman,+Kerman+Province,+Iran/@30.2766089,56.9968987,12z/data=!4m6!3m5!1s0x3f021851dbb1d0d1:0xcd1f7455f5d78eb6!8m2!3d30.2839379!4d57.0833628!16zL20vMDNncGtn'> KERMAN, IRAN </a>

---
Welcome to my personal webpage! I'm Mohammadamin Darijani, a recently graduated dentist and aspiring health professional with a passion for biomedical sciences and medical biotechnologies. While my journey began in dentistry, I've embarked on a new path, embracing a broader and interdisciplinary approach to healthcare.

My current mission is to expand my horizons in the realm of biomedical sciences and medical biotechnologies, merging my dental background with advanced knowledge in these fields. My goal is to contribute to cutting-edge research and innovation, ultimately enhancing patient care. By embracing this interdisciplinary perspective, I aspire to gain a holistic understanding of oral health and diseases, delving deep into their cellular and molecular intricacies.

This website serves as a platform to document my journey, share insights, and connect with fellow enthusiasts in the field. I'll be exploring a wide range of topics related to biomedical sciences, medical biotechnologies, and their applications in healthcare. Join me as I navigate this exciting new chapter and work towards making a meaningful impact in the world of healthcare and research.

Thank you for visiting, and I hope you find this page both informative and inspiring as we embark on this journey together.








##### CV/Resume
[Curriculum Vitae](https://drive.google.com/file/d/10CaE62SCxMwSfPhmFCNJbpt4Rbko7hRS/view?usp=share_link)  
[Resume](https://drive.google.com/file/d/1qtIZU1ph_XFNdA312VnQZl8ud3zMy1Hx/view?usp=share_link)
##### Degrees Certificate and Transcripts
[Doctorate Certificate]({{ site.url }}/assets/pdf/BSc_degree.pdf)  
[Doctorate Transcripts]({{ site.url }}/assets/pdf/Transcripts_bachelor.pdf)  

##### Skills

* Scientific Proposal Writing and Implementation
  - Designing Scientific Studies (observational, experimental, clinical trial, and review)
  - Data Extraction & Data Entry (into spreadsheets and statistical software) 
  - Data Analysis (qualitative and quantitative analysis)
  
* Computer & Data Management:
  - Statistical Software and Programming Languages 
  - SPSS: Intermediate Level 
  - R Studio 
  - Python
  - Stata
  - CMA: Basic Knowledge)

* Content Management Systems and Web Developing 
  - WordPress: Intermediate Level 
  - Drupal: Intermediate Level
  
* Reference Management Software 
  - Mendeley: Proficient
  - EndNote: Intermediate Level
  - Microsoft Office 

##### English Certificate
[TOEFL(Test of English as a Foreign Language) by ETS](https://drive.google.com/file/d/1L8bQB3dtSp5eHrdgO8KFvlKWHw-D9tqj/view?usp=share_link) 
##### Letters of Recommendation
[Dr. Masoud Parirokh (Full Professor, DDS, M.Sc.)](https://drive.google.com/file/d/1Dkt_L-b_LxQrl7CBdZ1VEnoWOtn3zyKK/view?usp=share_link)  
[Dr. Elham Farokh Gisour (Associated Professor, DDS, M.Sc.)](https://drive.google.com/file/d/1Qf5PIwY-x6z6rvFKdgKMYaw-chgOVztD/view?usp=share_link)  





