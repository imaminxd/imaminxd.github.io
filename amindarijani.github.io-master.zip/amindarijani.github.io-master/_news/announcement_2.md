---
layout: post
date: 2016-10-18 00:00:00-0400
inline: true
---

Launching [Asiakadeh Ecotourism Resort](https://adarijani.github.io/asiakadeh-ecotourism-resort/).
