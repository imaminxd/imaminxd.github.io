---
layout: post
date: 2015-09-22 00:00:00-0400
inline: true
---

Launching [Tara Educational school](https://adarijani.github.io/tara-educational-complex/).
